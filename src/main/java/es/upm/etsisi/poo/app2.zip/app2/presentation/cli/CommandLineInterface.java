package es.upm.etsisi.poo.app2.presentation.cli;

public class CommandLineInterface {
}
