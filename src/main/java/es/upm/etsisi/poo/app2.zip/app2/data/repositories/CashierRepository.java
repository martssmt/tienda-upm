package es.upm.etsisi.poo.app2.data.repositories;

import es.upm.etsisi.poo.app2.services.Service;

public interface CashierRepository extends Service {
}
