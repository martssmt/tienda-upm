package es.upm.etsisi.poo.app2.data.model.shop;

import es.upm.etsisi.poo.app2.data.model.Entity;

public abstract class Product extends Entity {
}
