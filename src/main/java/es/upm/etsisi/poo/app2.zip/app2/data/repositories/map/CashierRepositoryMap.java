package es.upm.etsisi.poo.app2.data.repositories.map;

public class CashierRepositoryMap extends RepositoryMap{
}
