package es.upm.etsisi.poo.app2.services;

public interface Service {
}
