package es.upm.etsisi.poo.app2.presentation.cli.commands.product;

import es.upm.etsisi.poo.app2.presentation.cli.Command;

public class ProdAddMeeting implements Command {
}
