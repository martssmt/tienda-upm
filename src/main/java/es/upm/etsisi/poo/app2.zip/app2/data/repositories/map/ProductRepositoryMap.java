package es.upm.etsisi.poo.app2.data.repositories.map;

public class ProductRepositoryMap extends RepositoryMap{
}
