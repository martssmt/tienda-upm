package es.upm.etsisi.poo.app2.presentation.cli.commands.user;

import es.upm.etsisi.poo.app2.presentation.cli.Command;

public class CashAdd implements Command {
}
