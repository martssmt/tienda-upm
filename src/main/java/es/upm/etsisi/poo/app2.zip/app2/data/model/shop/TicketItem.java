package es.upm.etsisi.poo.app2.data.model.shop;

public class TicketItem {
}
