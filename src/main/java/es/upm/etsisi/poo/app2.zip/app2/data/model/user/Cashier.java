package es.upm.etsisi.poo.app2.data.model.user;

public class Cashier extends User{
}
