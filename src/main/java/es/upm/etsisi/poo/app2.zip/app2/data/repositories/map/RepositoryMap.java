package es.upm.etsisi.poo.app2.data.repositories.map;

import es.upm.etsisi.poo.app2.data.repositories.Repository;

public abstract class RepositoryMap implements Repository {
}
