package es.upm.etsisi.poo.app2.data.model.exceptions;

public class InvalidAttributeException extends RuntimeException {
    public InvalidAttributeException(String message) {
        super(message);
    }
}
