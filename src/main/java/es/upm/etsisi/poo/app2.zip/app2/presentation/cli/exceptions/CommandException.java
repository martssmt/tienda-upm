package es.upm.etsisi.poo.app2.presentation.cli.exceptions;

public class CommandException extends RuntimeException {
    public CommandException(String message) {
        super(message);
    }
}
