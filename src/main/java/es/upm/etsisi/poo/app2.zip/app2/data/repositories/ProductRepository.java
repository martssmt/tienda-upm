package es.upm.etsisi.poo.app2.data.repositories;

public interface ProductRepository extends Repository {
}
