package es.upm.etsisi.poo.app2;

public class App {
    public static void main(String[] args) {

    }
}
