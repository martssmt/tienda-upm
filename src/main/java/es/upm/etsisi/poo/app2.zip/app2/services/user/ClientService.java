package es.upm.etsisi.poo.app2.services.user;

import es.upm.etsisi.poo.app2.services.Service;

public class ClientService implements Service {
}
