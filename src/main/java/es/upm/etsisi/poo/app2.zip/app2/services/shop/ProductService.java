package es.upm.etsisi.poo.app2.services.shop;

import es.upm.etsisi.poo.app2.services.Service;

public class ProductService implements Service {
}
