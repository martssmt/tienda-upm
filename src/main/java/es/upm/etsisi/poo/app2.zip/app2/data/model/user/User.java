package es.upm.etsisi.poo.app2.data.model.user;

import es.upm.etsisi.poo.app2.data.model.Entity;

public class User extends Entity {
}
