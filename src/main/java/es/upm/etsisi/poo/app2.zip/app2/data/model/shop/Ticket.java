package es.upm.etsisi.poo.app2.data.model.shop;

import es.upm.etsisi.poo.app2.data.model.Entity;

public class Ticket extends Entity {
}
