package es.upm.etsisi.poo.app2;

public class DependencyInjector {
}
