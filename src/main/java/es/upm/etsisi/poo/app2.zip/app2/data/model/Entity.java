package es.upm.etsisi.poo.app2.data.model;

public class Entity {
}
