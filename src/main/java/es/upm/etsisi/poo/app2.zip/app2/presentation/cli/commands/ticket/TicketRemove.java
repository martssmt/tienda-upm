package es.upm.etsisi.poo.app2.presentation.cli.commands.ticket;

import es.upm.etsisi.poo.app2.presentation.cli.Command;

public class TicketRemove implements Command {
}
