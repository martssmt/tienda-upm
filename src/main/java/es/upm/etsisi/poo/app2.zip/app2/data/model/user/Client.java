package es.upm.etsisi.poo.app2.data.model.user;

public class Client extends User{
}
