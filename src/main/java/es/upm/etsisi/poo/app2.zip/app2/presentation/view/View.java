package es.upm.etsisi.poo.app2.presentation.view;

public class View {
}
